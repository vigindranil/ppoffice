import OfficeAdminDashboard from '@/components/PpOfficeAdminDashboard'

export default function Home() {
  return <OfficeAdminDashboard />
}