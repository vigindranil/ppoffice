import SuperAdminDashboard from '@/components/SuperAdminDashboard'

export default function Home() {
  return <SuperAdminDashboard />
}