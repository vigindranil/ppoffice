import { Loader } from 'lucide-react';

const loading = () => {
  return (
    <Loader size={16} color="#00ff6e" />
  );
};

export default loading;
