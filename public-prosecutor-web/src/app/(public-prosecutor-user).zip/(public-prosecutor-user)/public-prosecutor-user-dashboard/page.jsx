import UserDashboard from '@/components/PpUserDashboard'

export default function Home() {
  return <UserDashboard />
}